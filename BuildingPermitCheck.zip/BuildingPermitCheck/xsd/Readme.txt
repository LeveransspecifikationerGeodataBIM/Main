Move this folder to  C:
(Not required if the xsd-files are already copied to C: from this GitHUB)